# -*- coding: utf-8 -*-
"""
Created on Tue Nov  4 10:29:01 2014

@author: Anthony Larcher

This script run an experiment on the male evaluation part of the RSR2015
database. The protocols used here is based on the one described in [Larcher14].
In this version, we only consider the non-target trials where impostors
pronounce the correct text (Imp Correct).

The number of Target trials performed is then
TAR correct: 10,244
IMP correct: 573,664

[Larcher14] Anthony Larcher, Kong Aik Lee, Bin Ma and Haizhou Li, 
"Text-dependent speaker verification: Classifiers, databases and RSR2015," 
in Speech Communication 60 (2014) 56–77
"""


import sidekit
import os
import sys
import multiprocessing
import matplotlib.pyplot as mpl
import logging
import numpy as np

logging.basicConfig(filename='log/rsr2015_ubm-gmm.log',level=logging.DEBUG)

#################################################################
# Set your own parameters
#################################################################
distribNb = 128  # number of Gaussian distributions for each GMM
rsr2015Path = '/Users/larcher/LIUM/RSR2015/RSR2015_V1/'

# Default for RSR2015
audioDir = os.path.join(rsr2015Path , 'sph/male')

# Automatically set the number of parallel process to run.
# The number of threads to run is set equal to the number of cores available 
# on the machine minus one or to 1 if the machine has a single core.
nbThread = max(multiprocessing.cpu_count()-1, 1)


#################################################################
# Load IdMap, Ndx, Key from HDF5 files and ubm_list
#################################################################
print('Load task definition')
enroll_idmap = sidekit.IdMap('task/3sesspwd_eval_m_trn.h5')
test_ndx = sidekit.Ndx('task/3sess-pwd_eval_m_ndx.h5')
key = sidekit.Key('task/3sess-pwd_eval_m_key.h5')
with open('task/ubm_list.txt') as inputFile:
    ubmList = inputFile.read().split('\n')


#%%
#################################################################
# Process the audio to generate MFCC
#################################################################
print('Create FeatureServer to extract MFCC features')
fs = sidekit.FeaturesServer(input_dir=audioDir,
                 input_file_extension='.sph',
                 label_dir='./',
                 label_file_extension='.lbl',
                 from_file='audio',
                 config='sid_16k')


#%%
#################################################################
# Train the Universal background Model (UBM)
#################################################################
print('Train the UBM by EM')
# Extract all features without writing to disk
data = fs.load_and_stack(np.array(ubmList), numThread=nbThread)
ubm = sidekit.Mixture()
llk = ubm.EM_split(data, distribNb, numThread=nbThread)
ubm.save_pickle('gmm/ubm.p')


#%%
#################################################################
# Compute the sufficient statistics on the UBM
#################################################################
print('Compute the sufficient statistics')
# Create a StatServer for the enrollment data and compute the statistics
enroll_stat = sidekit.StatServer(enroll_idmap)
enroll_stat.accumulate_stat_parallel(ubm, fs, numThread=nbThread)
enroll_stat.save('data/stat_rsr2015_male_enroll.h5')


#%%
#################################################################
# Adapt the GMM speaker models from the UBM via a MAP adaptation
#################################################################
print('MAP adaptation of the speaker models')
regulation_factor = 3  # MAP regulation factor
enroll_sv = enroll_stat.adapt_mean_MAP(ubm, regulation_factor)
enroll_sv.save('data/sv_rsr2015_male_enroll.h5')


#%%
#################################################################
# Compute all trials and save scores in HDF5 format
#################################################################
print('Compute trial scores')
scores_gmm_ubm = sidekit.gmm_scoring(ubm, 
                                   enroll_sv, 
                                   test_ndx,
                                   fs, 
                                   numThread=nbThread)
scores_gmm_ubm.save('scores/scores_gmm-ubm_rsr2015_male.h5')


#%%
#################################################################
# Plot DET curve and compute minDCF and EER
#################################################################
print('Plot the DET curve')
# Set the prior following NIST-SRE 2008 settings
prior = sidekit.effective_prior(0.01, 10, 1)
# Initialize the DET plot to 2008 settings
dp = sidekit.DetPlot(windowStyle='old', plotTitle='GMM-UBM RSR2015 male')
dp.set_system_from_scores(scores_gmm_ubm, key, sys_name='GMM-UBM')
dp.create_figure()
dp.plot_rocch_det(0)
dp.plot_DR30_both(idx=0)
dp.plot_mindcf_point(prior, idx=0)

