# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 13:36:47 2014

@author: Anthony Larcher

This script prepare the lists and indexes requierd to run an experiment 
on the male evaluation part of the RSR2015 database. 
The protocols used here is based on the one described in [Larcher14].
In this version, we only consider the non-target trials where impostors
pronounce the correct text (Imp Correct).

The number of Target trials performed is then
TAR correct: 10,244
IMP correct: 573,664

[Larcher14] Anthony Larcher, Kong Aik Lee, Bin Ma and Haizhou Li, 
"Text-dependent speaker verification: Classifiers, databases and RSR2015," 
in Speech Communication 60 (2014) 56–77
"""


import numpy as np
import sidekit
import os
import sys
import re
import random
import pandas as pd


rsr2015Path = '/Users/larcher/LIUM/RSR2015/RSR2015_V1/'


############################################################
# Convert the trn file from RSR2015 into SIDEKIT format
############################################################
print('Create the enrollment list from 3sesspwd_eval_m.trn')
rsrEnroll = pd.read_csv(rsr2015Path + '/key/part1/trn/3sesspwd_eval_m.trn', 
                        delimiter='[,\s*]', header=None, engine='python')
# remove the extension of the files (.sph)
for i in range(1,4):
    rsrEnroll[i] = rsrEnroll[i].str.replace('.sph$', '')
    rsrEnroll[i] = rsrEnroll[i].str.replace('^male/', '')

# Create the list of models and enrollment sessions
models = []
segments = []
for idx, mod in enumerate(rsrEnroll[0]):
    models.extend([mod, mod, mod])
    segments.extend([rsrEnroll[1][idx], rsrEnroll[2][idx], rsrEnroll[3][idx]])

# Create and fill the IdMap with the enrollment definition
enroll_idmap = sidekit.IdMap()
enroll_idmap.leftids = np.asarray(models)
enroll_idmap.rightids = np.asarray(segments)
enroll_idmap.start = np.empty(enroll_idmap.rightids.shape, '|O')
enroll_idmap.stop = np.empty(enroll_idmap.rightids.shape, '|O')
enroll_idmap.validate()
enroll_idmap.save('task/3sesspwd_eval_m_trn.h5')


############################################################
# Convert the key file from RSR2015 into SIDEKIT format
############################################################
print('Create the Key object from 3sess-pwd_eval_m.ndx')
rsrKey = pd.read_csv(rsr2015Path + '/key/part1/ndx/3sess-pwd_eval_m.ndx', 
                        delimiter='[,\s*]', header=None, engine='python')
rsrKey[1] = rsrKey[1].str.replace('.sph$', '')

with open('task/3sess-pwd_eval_m_key.txt', 'w') as of:
    for idx,model in enumerate(list(rsrKey[0])):
        if (rsrKey[2][idx] == 'Y'):
            of.write('{} {} target\n'.format(rsrKey[0][idx], rsrKey[1][idx]))
        elif (rsrKey[4][idx] == 'Y'):
            of.write('{} {} nontarget\n'.format(rsrKey[0][idx], rsrKey[1][idx]))
key = sidekit.Key('task/3sess-pwd_eval_m_key.txt','txt')
key.save('task/3sess-pwd_eval_m_key.h5')


############################################################
# Create the Ndx object from the Key object and save it in HDF5
############################################################
print('Create the Ndx object from the Key')
ndx = key.to_ndx()
ndx.save('task/3sess-pwd_eval_m_ndx.h5')


############################################################ 
# Create a list to train the UBM by selecting sentences 001 to 030 within the 
# background set of male speakers (from m001 to m050)
############################################################
print('Create the training list for the UBM')
ubmList = []
p = re.compile('(.*)((m0[0-4][0-9])|(m050))(.*)((0[0-2][0-9])|(030))(\.sph$)')
for dir_, _, files in os.walk(rsr2015Path):
    for fileName in files:
        if p.search(fileName):
            relDir = os.path.relpath(dir_, rsr2015Path + "/sph/male")
            relFile = os.path.join(relDir, fileName)
            ubmList.append(os.path.splitext(relFile)[0])
with open('task/ubm_list.txt','w') as of:
    of.write("\n".join(ubmList))   
 

############################################################
# Create an IdMap to train the NAP
############################################################
print('Create the training list for the NAP matrix')
napSegments = ubmList[::7]
napSpeakers = [seg.split('/')[0] for seg in napSegments]
nap_idmap = sidekit.IdMap()
nap_idmap.leftids = np.array(napSpeakers)
nap_idmap.rightids = np.array(napSegments)
nap_idmap.start = np.empty(nap_idmap.rightids.shape, '|O')
nap_idmap.stop = np.empty(nap_idmap.rightids.shape, '|O')
nap_idmap.validate()
nap_idmap.save('task/3sess-pwd_eval_m_nap.h5')


############################################################
# Create an IdMap to use as background speakers to train the SVMs
############################################################
print('Create the training list for the SVM blacklist')
backSegments = random.sample(ubmList, 200)
backSpeakers = [seg.split('/')[0] for seg in backSegments]
back_idmap = sidekit.IdMap()
back_idmap.leftids = np.array(backSpeakers)
back_idmap.rightids = np.array(backSegments)
back_idmap.start = np.empty(back_idmap.rightids.shape, '|O')
back_idmap.stop = np.empty(back_idmap.rightids.shape, '|O')
back_idmap.validate()
back_idmap.save('task/3sess-pwd_eval_m_back.h5')

############################################################
# Create an IdMap to copute the test segment statistics
############################################################
print('Create the IdMap for the test segments')
test_idmap = sidekit.IdMap()
test_idmap.leftids = ndx.segset
test_idmap.rightids = ndx.segset
test_idmap.start = np.empty(test_idmap.rightids.shape, '|O')
test_idmap.stop = np.empty(test_idmap.rightids.shape, '|O')
test_idmap.validate()
test_idmap.save('task/3sess-pwd_eval_m_test.h5')

