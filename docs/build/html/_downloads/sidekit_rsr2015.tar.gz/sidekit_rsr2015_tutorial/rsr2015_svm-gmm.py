# -*- coding: utf-8 -*-
"""
Created on Tue Nov  4 10:29:01 2014

@author: Anthony Larcher

This script run an experiment on the male evaluation part of the RSR2015
database. The protocols used here is based on the one described in [Larcher14].
In this version, we only consider the non-target trials where impostors
pronounce the correct text (Imp Correct).

The number of Target trials performed is then
TAR correct: 10,244
IMP correct: 573,664

[Larcher14] Anthony Larcher, Kong Aik Lee, Bin Ma and Haizhou Li, 
"Text-dependent speaker verification: Classifiers, databases and RSR2015," 
in Speech Communication 60 (2014) 56–77
"""


import numpy as np
import sidekit
import multiprocessing
import os
import sys
import matplotlib.pyplot as mpl
import logging

logging.basicConfig(filename='example.log',level=logging.INFO)
#logging.basicConfig(level=logging.DEBUG)


#################################################################
# Set your own parameters
#################################################################
distribNb = 128  # number of Gaussian distributions for each GMM
NAP = True  # activate the Nuisance Attribute Projection
nap_rank = 40
rsr2015Path = '/lium/parolee/larcher/data/RSR2015_V1/'


# Default for RSR2015
audioDir = os.path.join(rsr2015Path , 'sph/male')


# Automatically set the number of parallel process to run.
# The number of threads to run is set equal to the number of cores available 
# on the machine minus one or to 1 if the machine has a single core.
nbThread = max(multiprocessing.cpu_count()-1, 1)


#################################################################
# Load IdMap, Ndx, Key from HDF5 files and ubm_list
#################################################################
print('Load task definition')
enroll_idmap = sidekit.IdMap('task/3sesspwd_eval_m_trn.h5')
nap_idmap = sidekit.IdMap('task/3sess-pwd_eval_m_nap.h5')
back_idmap = sidekit.IdMap('task/3sess-pwd_eval_m_back.h5')
test_ndx = sidekit.Ndx('task/3sess-pwd_eval_m_ndx.h5')
test_idmap = sidekit.IdMap('task/3sess-pwd_eval_m_test.h5')
key = sidekit.Key('task/3sess-pwd_eval_m_key.h5')
with open('task/ubm_list.txt') as inputFile:
    ubmList = inputFile.read().split('\n')

#%%
#################################################################
# Process the audio to generate MFCC
#################################################################
print('Initialize FeaturesServers')
fs = sidekit.FeaturesServer(input_dir=audioDir,
                 input_file_extension='.sph',
                 label_dir='./',
                 label_file_extension='.lbl',
                 from_file='audio',
                 config='sid_16k')    

#%%
#################################################################
# Train the Universal background Model (UBM)
#################################################################
print('Train the UBM by EM')
# load all features in a list of arrays
ubm = sidekit.Mixture()
llk = ubm.EM_split(fs, ubmList, distribNb, numThread=nbThread)
ubm.save_hdf5('gmm/ubm.h5')


#%%
#################################################################
# Compute the sufficient statistics on the UBM
#################################################################
print('Compute the sufficient statistics')
# Create a StatServer for the enrollment data and compute the statistics
enroll_stat = sidekit.StatServer(enroll_idmap, ubm)
enroll_stat.accumulate_stat(ubm=ubm, feature_server=fs, seg_indices=range(enroll_stat.segset.shape[0]), numThread=nbThread)
enroll_stat.save('data/stat_rsr2015_male_enroll.h5')

back_stat = sidekit.StatServer(back_idmap, ubm)
back_stat.accumulate_stat(ubm=ubm, feature_server=fs, seg_indices=range(back_stat.segset.shape[0]), numThread=nbThread)
back_stat.save('data/stat_rsr2015_male_back.h5')

nap_stat = sidekit.StatServer(nap_idmap, ubm)
nap_stat.accumulate_stat(ubm=ubm, feature_server=fs, seg_indices=range(nap_stat.segset.shape[0]), numThread=nbThread)
nap_stat.save('data/stat_rsr2015_male_nap.h5')

test_stat = sidekit.StatServer(test_idmap, ubm)
test_stat.accumulate_stat(ubm=ubm, feature_server=fs, seg_indices=range(test_stat.segset.shape[0]), numThread=nbThread)
test_stat.save('data/stat_rsr2015_male_test.h5')

#%%
#################################################################
# Adapt the GMM speaker models from the UBM via a MAP adaptation
# for target models, background speakers for SVM training, NAP 
# training and test segments
#################################################################
print('MAP adaptation of the speaker models')
regulation_factor = 3  # MAP regulation factor

enroll_sv = enroll_stat.adapt_mean_MAP(ubm, regulation_factor, norm=True)
enroll_sv.save('data/sv_rsr2015_male_enroll.h5')

back_sv = back_stat.adapt_mean_MAP(ubm, regulation_factor, norm=True)
back_sv.save('data/sv_rsr2015_male_back.h5')

nap_sv = nap_stat.adapt_mean_MAP(ubm, regulation_factor, norm=True)
nap_sv.save('data/sv_rsr2015_male_nap.h5')

test_sv = test_stat.adapt_mean_MAP(ubm, regulation_factor, norm=True)
test_sv.save('data/sv_rsr2015_male_test.h5')


#%%
#################################################################
# Apply Nuisance Attribute Projection if required
#################################################################
if NAP:
    print('Estimate and apply NAP')
    napMat = back_sv.get_nap_matrix_stat1(nap_rank);
    back_sv.stat1 = back_sv.stat1 \
                    - np.dot(np.dot(back_sv.stat1, napMat), napMat.transpose())
    enroll_sv.stat1 = enroll_sv.stat1 \
                    - np.dot(np.dot(enroll_sv.stat1, napMat), napMat.transpose())
    test_sv.stat1 = test_sv.stat1 \
                    - np.dot(np.dot(test_sv.stat1, napMat), napMat.transpose())


#%%
#################################################################
# Train the Support Vector Machine models
#################################################################
print('Train the SVMs')
sidekit.svm_training('svm/', back_sv, enroll_sv, numThread=nbThread)


#%%
#################################################################
# Compute all trials and save scores in HDF5 format
#################################################################
print('Compute trial scores')
scores_gmm_svm = sidekit.svm_scoring('svm/', test_sv, test_ndx, numThread=nbThread)
if NAP:
    scores_gmm_svm.save('scores/scores_svm-gmm_NAP_rsr2015_male.h5')
else:
    scores_gmm_svm.save('scores/scores_svm-gmm_rsr2015_male.h5')


#%%
#################################################################
# Plot DET curve and compute minDCF and EER
#################################################################
print('Plot the DET curve')
# Set the prior following NIST-SRE 2008 settings
prior = sidekit.effective_prior(0.01, 10, 1)
# Initialize the DET plot to 2008 settings
dp = sidekit.DetPlot(windowStyle='old', plotTitle='SVM-GMM RSR2015 male')
dp.set_system_from_scores(scores_gmm_svm, key, sys_name='SVM-GMM')
dp.create_figure()
dp.plot_rocch_det(0)
dp.plot_DR30_both(idx=0)
dp.plot_mindcf_point(prior, idx=0)

minDCF, Pmiss, Pfa, prbep, eer = sidekit.bosaris.detplot.fast_minDCF(dp.__tar__[0], dp.__non__[0], prior, normalize=False)
print("minDCF = {}, eer = {}".format(minDCF, eer))

