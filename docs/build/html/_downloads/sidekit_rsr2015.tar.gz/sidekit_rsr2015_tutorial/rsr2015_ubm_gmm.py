import sidekit
import os
import sys
import multiprocessing
import matplotlib.pyplot as mpl
import logging
import numpy as np

logging.basicConfig(filename='log/rsr2015_ubm-gmm.log',level=logging.DEBUG)

distribNb = 128  # number of Gaussian distributions for each GMM
rsr2015Path = '/lium/parolee/larcher/data/RSR2015_V1/'

# Default for RSR2015
audioDir = os.path.join(rsr2015Path , 'sph/male')

# Automatically set the number of parallel process to run.
# The number of threads to run is set equal to the number of cores available
# on the machine minus one or to 1 if the machine has a single core.
nbThread = max(multiprocessing.cpu_count()-1, 1)

print('Load task definition')
enroll_idmap = sidekit.IdMap('task/3sesspwd_eval_m_trn.h5')
test_ndx = sidekit.Ndx('task/3sess-pwd_eval_m_ndx.h5')
key = sidekit.Key('task/3sess-pwd_eval_m_key.h5')
with open('task/ubm_list.txt') as inputFile:
    ubmList = inputFile.read().split('\n')

fs = sidekit.FeaturesServer(input_dir=audioDir,
                 input_file_extension='.sph',
                 label_dir='./',
                 label_file_extension='.lbl',
                 from_file='audio',
                 config='sid_16k')

print('Train the UBM by EM')
# Extract all features and train a GMM without writing to disk
ubm = sidekit.Mixture()
llk = ubm.EM_split(fs, ubmList, distribNb, numThread=nbThread)
ubm.save_pickle('gmm/ubm.h5')

print('Compute the sufficient statistics')
# Create a StatServer for the enrollment data and compute the statistics
enroll_stat = sidekit.StatServer(enroll_idmap, ubm)
enroll_stat.accumulate_stat(ubm=ubm, feature_server=fs, seg_indices=range(enroll_stat.segset.shape[0]), numThread=nbThread)
enroll_stat.save('data/stat_rsr2015_male_enroll.h5')

print('MAP adaptation of the speaker models')
regulation_factor = 3  # MAP regulation factor
enroll_sv = enroll_stat.adapt_mean_MAP(ubm, regulation_factor)
enroll_sv.save('data/sv_rsr2015_male_enroll.h5')

print('Compute trial scores')
scores_gmm_ubm = sidekit.gmm_scoring(ubm,
                                   enroll_sv,
                                   test_ndx,
                                   fs,
                                   numThread=nbThread)
scores_gmm_ubm.save('scores/scores_gmm-ubm_rsr2015_male.h5')

print('Plot the DET curve')
# Set the prior following NIST-SRE 2008 settings
prior = sidekit.effective_prior(0.01, 10, 1)
# Initialize the DET plot to 2008 settings
dp = sidekit.DetPlot(windowStyle='old', plotTitle='GMM-UBM_RSR2015_male')
dp.set_system_from_scores(scores_gmm_ubm, key, sys_name='GMM-UBM')
dp.create_figure()
dp.plot_rocch_det(0)
dp.plot_DR30_both(idx=0)
dp.plot_mindcf_point(prior, idx=0)
